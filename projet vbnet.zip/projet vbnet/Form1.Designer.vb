﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        uti = New TextBox()
        mdp = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        con = New Button()
        Label4 = New Label()
        msg = New Label()
        SuspendLayout()
        ' 
        ' uti
        ' 
        uti.Location = New Point(209, 85)
        uti.Name = "uti"
        uti.Size = New Size(186, 23)
        uti.TabIndex = 0
        ' 
        ' mdp
        ' 
        mdp.Location = New Point(209, 132)
        mdp.Name = "mdp"
        mdp.Size = New Size(186, 23)
        mdp.TabIndex = 1
        mdp.UseSystemPasswordChar = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F)
        Label1.ForeColor = SystemColors.ControlLightLight
        Label1.Location = New Point(31, 87)
        Label1.Name = "Label1"
        Label1.Size = New Size(138, 21)
        Label1.TabIndex = 2
        Label1.Text = "Nom d'utilisateur :"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F)
        Label2.ForeColor = SystemColors.ControlLightLight
        Label2.Location = New Point(60, 134)
        Label2.Name = "Label2"
        Label2.Size = New Size(109, 21)
        Label2.TabIndex = 3
        Label2.Text = "Mot de passe :"
        ' 
        ' con
        ' 
        con.BackColor = SystemColors.InactiveCaption
        con.Location = New Point(209, 198)
        con.Name = "con"
        con.Size = New Size(186, 23)
        con.TabIndex = 6
        con.Text = "Se connecter"
        con.UseVisualStyleBackColor = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 18F, FontStyle.Bold)
        Label4.ForeColor = SystemColors.ControlLightLight
        Label4.Location = New Point(200, 21)
        Label4.Name = "Label4"
        Label4.Size = New Size(137, 32)
        Label4.TabIndex = 7
        Label4.Text = "Connexion"
        ' 
        ' msg
        ' 
        msg.AutoSize = True
        msg.ForeColor = SystemColors.ButtonFace
        msg.Location = New Point(282, 252)
        msg.Name = "msg"
        msg.Size = New Size(0, 15)
        msg.TabIndex = 8
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.MenuHighlight
        ClientSize = New Size(565, 296)
        Controls.Add(msg)
        Controls.Add(Label4)
        Controls.Add(con)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(mdp)
        Controls.Add(uti)
        Name = "Form1"
        Text = "Interface de connexion"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents uti As TextBox
    Friend WithEvents mdp As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents con As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents msg As Label

End Class
