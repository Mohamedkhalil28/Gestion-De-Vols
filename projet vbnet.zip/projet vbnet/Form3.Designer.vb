﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        volst = New DataGridView()
        num = New DataGridViewTextBoxColumn()
        des = New DataGridViewTextBoxColumn()
        dat = New DataGridViewTextBoxColumn()
        nbp = New DataGridViewTextBoxColumn()
        pri = New DataGridViewTextBoxColumn()
        Label3 = New Label()
        Label2 = New Label()
        dest = New TextBox()
        rech = New Button()
        Label1 = New Label()
        tel = New TextBox()
        pre = New TextBox()
        nom = New TextBox()
        btnres = New Button()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label4 = New Label()
        dateh = New DateTimePicker()
        CType(volst, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' volst
        ' 
        volst.BackgroundColor = SystemColors.ActiveCaption
        volst.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        volst.Columns.AddRange(New DataGridViewColumn() {num, des, dat, nbp, pri})
        volst.Location = New Point(319, 109)
        volst.Name = "volst"
        volst.Size = New Size(544, 151)
        volst.TabIndex = 1
        ' 
        ' num
        ' 
        num.HeaderText = "Numero de vol"
        num.Name = "num"
        ' 
        ' des
        ' 
        des.HeaderText = "La destination"
        des.Name = "des"
        ' 
        ' dat
        ' 
        dat.HeaderText = "La date et l'heure"
        dat.Name = "dat"
        ' 
        ' nbp
        ' 
        nbp.HeaderText = "NB Places disponibles"
        nbp.Name = "nbp"
        ' 
        ' pri
        ' 
        pri.HeaderText = "Prix"
        pri.Name = "pri"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label3.ForeColor = SystemColors.Control
        Label3.Location = New Point(26, 178)
        Label3.Name = "Label3"
        Label3.Size = New Size(73, 21)
        Label3.TabIndex = 14
        Label3.Text = "La date :"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label2.ForeColor = SystemColors.Control
        Label2.Location = New Point(26, 112)
        Label2.Name = "Label2"
        Label2.Size = New Size(126, 21)
        Label2.TabIndex = 13
        Label2.Text = "La destination :"
        ' 
        ' dest
        ' 
        dest.Location = New Point(155, 112)
        dest.Name = "dest"
        dest.Size = New Size(129, 23)
        dest.TabIndex = 12
        ' 
        ' rech
        ' 
        rech.BackColor = SystemColors.InactiveCaption
        rech.Location = New Point(83, 237)
        rech.Name = "rech"
        rech.Size = New Size(129, 23)
        rech.TabIndex = 16
        rech.Text = "Rechercher"
        rech.UseVisualStyleBackColor = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.MenuHighlight
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label1.ForeColor = SystemColors.Control
        Label1.Location = New Point(505, 348)
        Label1.Name = "Label1"
        Label1.Size = New Size(188, 21)
        Label1.TabIndex = 18
        Label1.Text = "Numero de Telephone :"
        ' 
        ' tel
        ' 
        tel.Location = New Point(700, 344)
        tel.Name = "tel"
        tel.Size = New Size(159, 23)
        tel.TabIndex = 17
        ' 
        ' pre
        ' 
        pre.Location = New Point(334, 344)
        pre.Name = "pre"
        pre.Size = New Size(152, 23)
        pre.TabIndex = 19
        ' 
        ' nom
        ' 
        nom.Location = New Point(79, 344)
        nom.Name = "nom"
        nom.Size = New Size(154, 23)
        nom.TabIndex = 21
        ' 
        ' btnres
        ' 
        btnres.BackColor = SystemColors.InactiveCaption
        btnres.ForeColor = SystemColors.ActiveCaptionText
        btnres.Location = New Point(363, 398)
        btnres.Name = "btnres"
        btnres.Size = New Size(113, 23)
        btnres.TabIndex = 23
        btnres.Text = "Reserver"
        btnres.UseVisualStyleBackColor = False
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 15F, FontStyle.Bold)
        Label6.ForeColor = SystemColors.ControlLightLight
        Label6.Location = New Point(391, 9)
        Label6.Name = "Label6"
        Label6.Size = New Size(125, 28)
        Label6.TabIndex = 24
        Label6.Text = "Reservation"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = SystemColors.MenuHighlight
        Label7.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label7.ForeColor = SystemColors.Control
        Label7.Location = New Point(352, 241)
        Label7.Name = "Label7"
        Label7.Size = New Size(0, 21)
        Label7.TabIndex = 26
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = SystemColors.MenuHighlight
        Label8.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label8.ForeColor = SystemColors.Control
        Label8.Location = New Point(250, 348)
        Label8.Name = "Label8"
        Label8.Size = New Size(78, 21)
        Label8.TabIndex = 27
        Label8.Text = "Prenom :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = SystemColors.MenuHighlight
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label4.ForeColor = SystemColors.Control
        Label4.Location = New Point(8, 348)
        Label4.Name = "Label4"
        Label4.Size = New Size(56, 21)
        Label4.TabIndex = 28
        Label4.Text = "Nom :"
        ' 
        ' dateh
        ' 
        dateh.CustomFormat = "dd/MM/yyyy HH:mm"
        dateh.Format = DateTimePickerFormat.Short
        dateh.Location = New Point(151, 178)
        dateh.Name = "dateh"
        dateh.Size = New Size(133, 23)
        dateh.TabIndex = 29
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.MenuHighlight
        ClientSize = New Size(884, 503)
        Controls.Add(dateh)
        Controls.Add(Label4)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(btnres)
        Controls.Add(nom)
        Controls.Add(pre)
        Controls.Add(Label1)
        Controls.Add(tel)
        Controls.Add(rech)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(dest)
        Controls.Add(volst)
        Name = "Form3"
        Text = "Reservation des billets (utilisateur)"
        CType(volst, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents volst As DataGridView
    Friend WithEvents num As DataGridViewTextBoxColumn
    Friend WithEvents des As DataGridViewTextBoxColumn
    Friend WithEvents dat As DataGridViewTextBoxColumn
    Friend WithEvents nbp As DataGridViewTextBoxColumn
    Friend WithEvents pri As DataGridViewTextBoxColumn
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents dest As TextBox
    Friend WithEvents rech As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents tel As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents pre As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents nom As TextBox
    Friend WithEvents btnres As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents dateh As DateTimePicker
End Class
